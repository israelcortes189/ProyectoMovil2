package com.example.marsphotos.data.Entityes

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "calificaciones_finales")
data class CalificacionFinalEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val matricula: String,
    val materia: String,
    val grupo: String,
    val calif: Int,
    val acreditacion: String,
    val observaciones: String
)

