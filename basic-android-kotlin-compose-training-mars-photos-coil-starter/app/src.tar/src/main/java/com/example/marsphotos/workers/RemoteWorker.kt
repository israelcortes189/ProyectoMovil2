package com.example.marsphotos.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.example.marsphotos.repository.MainRepository
import com.google.gson.Gson

class RemoteWorker(
    context: Context,
    params: WorkerParameters,
    private val mainRepository: MainRepository
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val tipo = inputData.getString("tipo") ?: return Result.failure()
            val matricula = inputData.getString("matricula") ?: return Result.failure()

            val result = when (tipo) {
                "perfil" -> mainRepository.remoteRepository.profile()
                "carga" -> mainRepository.remoteRepository.cargaAcademica()
                "cardex" -> mainRepository.remoteRepository.cardex(3)
                "califUnidades" -> mainRepository.remoteRepository.calificacionesPorUnidad()
                "califFinal" -> mainRepository.remoteRepository.calificacionFinal(9)
                else -> null
            }

            val output = workDataOf(
                "tipo" to tipo,
                "matricula" to matricula,
                "result" to Gson().toJson(result)
            )
            Result.success(output)
        } catch (e: Exception) {
            Result.failure()
        }
    }
}
