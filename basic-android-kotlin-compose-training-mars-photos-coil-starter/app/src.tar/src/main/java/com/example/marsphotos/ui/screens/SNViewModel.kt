/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.marsphotos.ui.screens

import android.content.Context
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.asFlow
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.example.marsphotos.MarsPhotosApplication
import com.example.marsphotos.data.Entityes.CalificacionFinalEntity
import com.example.marsphotos.data.Entityes.CalificacionUnidadEntity
import com.example.marsphotos.data.Entityes.CardexEntity
import com.example.marsphotos.data.Entityes.CargaEntity
import com.example.marsphotos.repository.LocalRepository
import com.example.marsphotos.repository.MainRepository

import com.example.marsphotos.repository.NetworSNRepository
import com.example.marsphotos.data.Entityes.ProfileEntity
import com.example.marsphotos.model.MarsPhoto
import com.example.marsphotos.workers.LocalWorker
import com.example.marsphotos.workers.RemoteWorker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.mapNotNull
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch

/**
 * UI state for the Home screen
 */
sealed interface SNUiState {
    data class Success(val accesoLogin: String ) : SNUiState
    object Error : SNUiState
    object Loading : SNUiState
}


class SNViewModel(private val repository: MainRepository,
                  private val appContext: Context
    ) : ViewModel() {

    /** The mutable State that stores the status of the most recent request */
    var snUiState: SNUiState by mutableStateOf(SNUiState.Loading)
        private set

    fun hasSession(): Boolean =
        repository.hasSession()

    //Funcion para cerrar sesion en el repositori, asignar perfil como nulo
    // y asignar el estado de la sesion como cargando
    fun logout() {
        repository.logout()
        profileState = null
        snUiState = SNUiState.Loading
    }

    var profileState by mutableStateOf<ProfileEntity?>(null)

    var isLoading by mutableStateOf(false)
        private set

    fun loadProfile() {
        if (!repository.hasSession()) return
        viewModelScope.launch {
            isLoading = true
            try {
                // Obtén la matrícula actual desde el repositorio remoto
                val matricula = repository.remoteRepository.currentMatricula ?: return@launch

                // Observa directamente el Flow de Room
                repository.localRepository.getProfile(matricula).collect { perfil ->
                    Log.d("VIEWMODEL", "Perfil emitido desde Room: $perfil")
                    profileState = perfil
                }
            } catch (e: Exception) {
                Log.e("PROFILE", "Error cargando perfil", e)
            } finally {
                isLoading = false
            }
        }
    }



    /**
     * Call getMarsPhotos() on init so we can display status immediately.
     */
    init {
        checkSession()
    }

    //Funcion para chacar si hay sesion activa en el repositori
    //tambien revisar si hay un perfil activo, en caso contrario ejecuta en el repositorio
    //la funcion cerrar secion para que se mande al flujo pedir un nuevo inicio de secion
    private fun checkSession() {
        viewModelScope.launch {
            if (repository.hasSession()) {
                val matricula = repository.remoteRepository.currentMatricula ?: return@launch
                val profile = repository.getProfile(matricula, online = true)
                if (profile == null) {
                    repository.logout()
                    snUiState = SNUiState.Error
                } else {
                    profileState = profile
                }
            }
        }
    }

    /**
     * Gets Mars photos information from the Mars API Retrofit service and updates the
     * [MarsPhoto] [List] [MutableList].
     */
    fun accesoSN(usuario: String, password: String) {
        viewModelScope.launch {
            snUiState = SNUiState.Loading
            try {
                val result = repository.acceso(usuario, password)

                if (result == "OK") {
                    snUiState = SNUiState.Success(result)
                    loadProfile()
                } else {
                    snUiState = SNUiState.Error
                }

                Log.d("LOGIN", "Resultado del repo: '$result'")
            } catch (e: Exception) {
                snUiState = SNUiState.Error
            }
        }
    }

    fun loadCardex(lineamiento: Int) {
        viewModelScope.launch {
            try {
                val cardexList = repository.remoteRepository.cardex(lineamiento)
                if (cardexList != null) {
                    Log.d("VIEWMODEL_CARDEX", "Cardex recibido: $cardexList")
                } else {
                    Log.e("VIEWMODEL_CARDEX", "No se recibió información del cardex")
                }
            } catch (e: Exception) {
                Log.e("VIEWMODEL_CARDEX", "Error cargando cardex", e)
            }
        }
    }

    fun loadCargaAcademica() {
        viewModelScope.launch {
            try {
                val cargaList = repository.remoteRepository.cargaAcademica()
                if (cargaList != null) {
                    Log.d("VIEWMODEL_CARGA", "Carga académica recibida: $cargaList")
                } else {
                    Log.e("VIEWMODEL_CARGA", "No se recibió información de carga académica")
                }
            } catch (e: Exception) {
                Log.e("VIEWMODEL_CARGA", "Error cargando carga académica", e)
            }
        }
    }

    fun loadCalificacionesPorUnidad() {
        viewModelScope.launch {
            try {
                val califList = repository.remoteRepository.calificacionesPorUnidad()
                if (califList != null) {
                    Log.d("VIEWMODEL_CALIF_UNIDADES", "Calificaciones recibidas: $califList")
                } else {
                    Log.e(
                        "VIEWMODEL_CALIF_UNIDADES",
                        "No se recibió información de calificaciones por unidad"
                    )
                }
            } catch (e: Exception) {
                Log.e("VIEWMODEL_CALIF_UNIDADES", "Error cargando calificaciones por unidad", e)
            }
        }
    }

    fun loadCalificacionFinal(modEducativo: Int) {
        viewModelScope.launch {
            try {
                val califFinalList = repository.remoteRepository.calificacionFinal(modEducativo)
                if (califFinalList != null) {
                    Log.d("VIEWMODEL_CALIF_FINAL", "Calificación final recibida: $califFinalList")
                } else {
                    Log.e("VIEWMODEL_CALIF_FINAL", "No se recibió información de calificación final")
                }
            } catch (e: Exception) {
                Log.e("VIEWMODEL_CALIF_FINAL", "Error cargando calificación final", e)
            }
        }
    }

    private val _cardexState = MutableStateFlow<List<CardexEntity>>(emptyList())
    val cardexState: StateFlow<List<CardexEntity>> = _cardexState

    fun loadCardex(matricula: String, lineamiento: Int, online: Boolean) {
        viewModelScope.launch {
            try {
                val cardexList = repository.getCardex(matricula, lineamiento, online)
                if (cardexList != null) {
                    _cardexState.value = cardexList
                    Log.d("VIEWMODEL_CARDEX", "Cardex recibido: $cardexList")
                } else {
                    Log.e("VIEWMODEL_CARDEX", "No se recibió información del cardex")
                }
            } catch (e: Exception) {
                Log.e("VIEWMODEL_CARDEX", "Error cargando cardex", e)
            }
        }
    }

    private val _calificacionesState = MutableStateFlow<List<CalificacionUnidadEntity>>(emptyList())
    val calificacionesState: StateFlow<List<CalificacionUnidadEntity>> = _calificacionesState

    fun loadCalificacionesPorUnidad(matricula: String, online: Boolean) {
        viewModelScope.launch {
            try {
                val calificaciones = repository.getCalificacionesPorUnidad(matricula, online)
                if (calificaciones != null) {
                    _calificacionesState.value = calificaciones
                    Log.d("VIEWMODEL_CALIF_UNIDADES", "Calificaciones recibidas: $calificaciones")
                } else {
                    Log.e(
                        "VIEWMODEL_CALIF_UNIDADES",
                        "No se recibió información de calificaciones por unidad"
                    )
                }
            } catch (e: Exception) {
                Log.e("VIEWMODEL_CALIF_UNIDADES", "Error cargando calificaciones por unidad", e)
            }
        }
    }

    private val _cargaState = MutableStateFlow<List<CargaEntity>>(emptyList())
    val cargaState: StateFlow<List<CargaEntity>> = _cargaState

    fun loadCargaAcademica(matricula: String, online: Boolean) {
        viewModelScope.launch {
            try {
                val cargaList = repository.getCargaAcademica(matricula, online)
                if (cargaList != null) {
                    _cargaState.value = cargaList
                    Log.d("VIEWMODEL_CARGA", "Carga académica recibida: $cargaList")
                } else {
                    Log.e("VIEWMODEL_CARGA", "No se recibió información de carga académica")
                }
            } catch (e: Exception) {
                Log.e("VIEWMODEL_CARGA", "Error cargando carga académica", e)
            }
        }
    }

    private val _califFinalState = MutableStateFlow<List<CalificacionFinalEntity>>(emptyList())
    val califFinalState: StateFlow<List<CalificacionFinalEntity>> = _califFinalState

    fun loadCalificacionFinal(matricula: String, modEducativo: Int, online: Boolean) {
        viewModelScope.launch {
            try {
                val califFinalList = repository.getCalificacionFinal(matricula, modEducativo, online)
                if (califFinalList != null) {
                    _califFinalState.value = califFinalList
                    Log.d("VIEWMODEL_CALIF_FINAL", "Calificación final recibida: $califFinalList")
                } else {
                    Log.e("VIEWMODEL_CALIF_FINAL", "No se recibió información de calificación final")
                }
            } catch (e: Exception) {
                Log.e("VIEWMODEL_CALIF_FINAL", "Error cargando calificación final", e)
            }
        }
    }

    // Estado de sincronización
    private val _syncState = MutableStateFlow<WorkInfo?>(null)
    val syncState: StateFlow<WorkInfo?> = _syncState

    fun syncData(tipo: String, matricula: String) {
        val remoteRequest = OneTimeWorkRequestBuilder<RemoteWorker>()
            .setInputData(workDataOf("tipo" to tipo, "matricula" to matricula))
            .addTag("REMOTE_$tipo")
            .build()

        val localRequest = OneTimeWorkRequestBuilder<LocalWorker>()
            .setInputData(workDataOf("tipo" to tipo, "matricula" to matricula))
            .addTag("LOCAL_$tipo")
            .build()

        WorkManager.getInstance(appContext)
            .beginUniqueWork("sync_$tipo", ExistingWorkPolicy.REPLACE, remoteRequest)
            .then(localRequest)
            .enqueue()

        WorkManager.getInstance(appContext)
            .getWorkInfosForUniqueWorkLiveData("sync_$tipo")
            .asFlow()
            .onEach { infos ->
                val lastInfo = infos.lastOrNull()
                Log.d("SYNC", "Estado de sync_$tipo: $lastInfo")
                _syncState.value = lastInfo
            }
            .launchIn(viewModelScope)

    }



    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                val application = (this[APPLICATION_KEY] as MarsPhotosApplication)
                val localRepo = LocalRepository(
                    application.database.profileDao(),
                    application.database.cardexDao(),
                    application.database.cargaDao(),
                    application.database.CalificacionUnidadDao(),
                    application.database.CalificacionFinalDao()
                )
                val remoteRepo = application.container.snRepository as NetworSNRepository
                val mainRepo = MainRepository(localRepo, remoteRepo)
                SNViewModel(repository = mainRepo, appContext = application.applicationContext)
            }
        }
    }
}











