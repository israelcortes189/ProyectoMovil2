package com.example.marsphotos.workers

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.example.marsphotos.data.Entityes.ProfileEntity
import com.example.marsphotos.model.entityes.CalificacionFinalItem
import com.example.marsphotos.model.entityes.CalificacionUnidadItem
import com.example.marsphotos.model.entityes.CardexItem
import com.example.marsphotos.model.entityes.CargaItem
import com.example.marsphotos.repository.LocalRepository
import com.google.gson.Gson

class LocalWorker(
    context: Context,
    params: WorkerParameters,
    private val localRepository: LocalRepository
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val tipo = inputData.getString("tipo") ?: return Result.failure()
            val matricula = inputData.getString("matricula") ?: return Result.failure()
            val resultJson = inputData.getString("result") ?: return Result.failure()

            val gson = Gson()

            when (tipo) {
                "perfil" -> {
                    Log.d("LOCAL_WORKER", "Insertando perfil en Room: $resultJson")
                    val perfil = gson.fromJson(resultJson, ProfileEntity::class.java)
                    localRepository.insertProfile(perfil)
                }

                "carga" -> {
                    Log.d("LOCAL_WORKER", "JSON recibido para perfil: $resultJson")
                    val items = gson.fromJson(resultJson, Array<CargaItem>::class.java).toList()
                    localRepository.insertCarga(matricula, items)
                }
                "cardex" -> {
                    val items = gson.fromJson(resultJson, Array<CardexItem>::class.java).toList()
                    Log.d("LOCAL_WORKER", "JSON recibido para cardex: $resultJson")
                    Log.d("LOCAL_WORKER", "Items deserializados: $items")
                    localRepository.insertCardex(matricula, items)
                }
                "califUnidades" -> {
                    val items = gson.fromJson(resultJson, Array<CalificacionUnidadItem>::class.java).toList()
                    Log.d("LOCAL_WORKER", "JSON recibido: $resultJson")

                    localRepository.insertCalificaciones(matricula, items)
                }
                "califFinal" -> {
                    val items = gson.fromJson(resultJson, Array<CalificacionFinalItem>::class.java).toList()
                    Log.d("LOCAL_WORKER", "JSON recibido: $resultJson")
                    localRepository.insertCalificacionFinal(matricula, items)
                }
            }

            Result.success(workDataOf("status" to "inserted"))
        } catch (e: Exception) {
            Result.failure(workDataOf("error" to e.message))
        }
    }
}
